﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class EspecialidadController : Controller
    {
        private readonly TurnosContext _context;

        public EspecialidadController(TurnosContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Devuelve la tabla de especialidad
            return View(await _context.Especialidad.ToListAsync());
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var especialidad = await _context.Especialidad.FindAsync(id);

            if (especialidad == null)
            {
                return NotFound();
            }

            return View(especialidad);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEspecialidad,Descripcion")] Especialidad especialidad)
        {
            if (id != especialidad.IdEspecialidad)
            {
                return NotFound();
            }
                                   
                           
           
            
          
                try
                {
                    _context.Update(especialidad);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Especialidad actualizada con éxito.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EspecialidadExists(especialidad.IdEspecialidad))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                
                return RedirectToAction(nameof(Index));
            }
            return View(especialidad);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var especialidad = await _context.Especialidad.FirstOrDefaultAsync(e => e.IdEspecialidad == id);

            if (especialidad == null)
            {
                return NotFound();
            }

            return View(especialidad);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var especialidad = await _context.Especialidad.FindAsync(id);
            if (especialidad == null)
            {
                return NotFound();
            }

            try
            {
                _context.Especialidad.Remove(especialidad);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Especialidad eliminada con éxito.";
            }
            catch (DbUpdateException)
            {
                TempData["ErrorMessage"] = "Error al eliminar la especialidad. Inténtalo de nuevo.";
                return RedirectToAction(nameof(Delete), new { id });
            }

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdEspecialidad,Descripcion")] Especialidad especialidad)
        {
                          _context.Add(especialidad);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Especialidad creada con éxito.";
                return RedirectToAction(nameof(Index));
         
            return View(especialidad);
        }

        private bool EspecialidadExists(int id)
        {
            return _context.Especialidad.Any(e => e.IdEspecialidad == id);
        }
    }
}