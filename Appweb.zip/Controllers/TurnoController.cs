﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class TurnoController : Controller
    {
        private readonly TurnosContext _context;
        private readonly IConfiguration _configuration;

        public TurnoController(TurnosContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            ViewData["IdMedico"] = new SelectList(
                _context.Medico
                    .Select(m => new { m.IdMedico, NombreCompleto = m.Nombre + " " + m.Apellido })
                    .ToList(), "IdMedico", "NombreCompleto");
            ViewData["IdPaciente"] = new SelectList(
                _context.Paciente
                    .Select(p => new { p.IdPaciente, NombreCompleto = p.Nombre + " " + p.Apellido })
                    .ToList(), "IdPaciente", "NombreCompleto");
            return View();
        }

        public JsonResult ObtenerTurnos(int idMedico)
        {
            var turnos = _context.Turno
                .Where(t => t.IdMedico == idMedico)
                .Select(t => new {
                    t.IdTurno,
                    t.IdMedico,
                    t.IdPaciente,
                    t.FechaHoraInicio,
                    t.FechaHoraFin,
                    Paciente = t.Paciente.Nombre + " " + t.Paciente.Apellido
                })
                .ToList();

            return new JsonResult(turnos);
        }

        [HttpPost]
        public JsonResult GrabarTurno([FromBody] Turno turno)
        {
            var ok = false;
            try
            {
                if (turno.IdTurno == 0)
                {
                    _context.Turno.Add(turno);
                }
                else
                {
                    _context.Turno.Update(turno);
                }
                _context.SaveChanges();
                ok = true;
            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Excepcion Encontrada", e);
            }
            return new JsonResult(new { ok });
        }

        [HttpPost]
        public JsonResult EliminarTurno(int idTurno)
        {
            var ok = false;
            try
            {
                var turnoEliminar = _context.Turno.FirstOrDefault(t => t.IdTurno == idTurno);
                if (turnoEliminar != null)
                {
                    _context.Turno.Remove(turnoEliminar);
                    _context.SaveChanges();
                    ok = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Excepcion Encontrada", e);
            }
            return new JsonResult(new { ok });
        }
    }
}